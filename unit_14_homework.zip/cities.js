let cityList = [
  {
    "id": 703448,
    "name": "Kyiv",
    "state": "",
    "country": "UA",
    "coord": {
      "lon": 30.516666,
      "lat": 50.433334
    }
  },
  {
    "id": 2172517,
    "name": "Canberra",
    "state": "",
    "country": "AU",
    "coord": {
      "lon": 149.128067,
      "lat": -35.283459
    }
  },
  {
    "id": 5128581,
    "name": "New York City",
    "state": "NY",
    "country": "US",
    "coord": {
      "lon": -74.005966,
      "lat": 40.714272
    }
  },
  {
    "id": 3169070,
    "name": "Rome",
    "state": "",
    "country": "IT",
    "coord": {
      "lon": 12.4839,
      "lat": 41.894741
    }
  },
  {
    "id": 6692263,
    "name": "Reykjavik",
    "state": "",
    "country": "IS",
    "coord": {
      "lon": -21.85799,
      "lat": 64.118401
    }
  },
  {
    "id": 2253350,
    "name": "Dakar",
    "state": "",
    "country": "SN",
    "coord": {
      "lon": -17.33333,
      "lat": 14.75
    }
  }
]